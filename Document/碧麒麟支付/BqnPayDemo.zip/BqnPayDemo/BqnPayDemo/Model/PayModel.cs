﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Payment.Model
{
    public class PaySendModel
    {
        private string _merchant_account = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchant_account
        {
            get { return _merchant_account; }
            set { _merchant_account = value; }
        }
        private string _out_store_name = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string out_store_name
        {
            get { return _out_store_name; }
            set { _out_store_name = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string out_cashier_name
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }
        private string _local_time = "";
        /// <summary>
        /// 本地时间
        /// </summary>
        public string local_time
        {
            get { return _local_time; }
            set { _local_time = value; }
        }
        private string _out_goods_name = "";
        /// <summary>
        /// 商品名称
        /// </summary>
        public string out_goods_name
        {
            get { return _out_goods_name; }
            set { _out_goods_name = value; }
        }
        private string _out_trade_no = "";
        /// <summary>
        /// 交易号
        /// </summary>
        public string out_trade_no
        {
            get { return _out_trade_no; }
            set { _out_trade_no = value; }
        }
        private string _terminal_type = "";
        /// <summary>
        /// 终端类型
        /// </summary>
        public string terminal_type
        {
            get { return _terminal_type; }
            set { _terminal_type = value; }
        }
        private string _amount = "";
        /// <summary>
        /// 支付金额
        /// </summary>
        public string amount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string pay_type
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }
        private string _code = "";
        /// <summary>
        /// 用户支付码
        /// </summary>
        public string code
        {
            get { return _code; }
            set { _code = value; }
        }
        private string _fee_type = "";
        /// <summary>
        /// 币种
        /// </summary>
        public string fee_type
        {
            get { return _fee_type; }
            set { _fee_type = value; }
        }
        private string _partner_code = "";
        /// <summary>
        /// 第三方标识
        /// </summary>
        public string partner_code
        {
            get { return _partner_code; }
            set { _partner_code = value; }
        }
        private string _out_sub_appid = "";
        /// <summary>
        /// 公众号appid
        /// </summary>
        public string out_sub_appid
        {
            get { return _out_sub_appid; }
            set { _out_sub_appid = value; }
        }
        private string _notify_url = "";
        /// <summary>
        /// 支付结果回调地址
        /// </summary>
        public string notify_url
        {
            get { return _notify_url; }
            set { _notify_url = value; }
        }
        private string _out_sub_openid = "";
        /// <summary>
        /// 微信openId
        /// </summary>
        public string out_sub_openid
        {
            get { return _out_sub_openid; }
            set { _out_sub_openid = value; }
        }
        private string _token = "";
        /// <summary>
        /// Access token
        /// </summary>
        public string token
        {
            get { return _token; }
            set { _token = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }

    public class Jsapi_payReturnModel
    {
        private string _merchantAccount = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchantAccount
        {
            get { return _merchantAccount; }
            set { _merchantAccount = value; }
        }
        private string _outStoreName = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string outStoreName
        {
            get { return _outStoreName; }
            set { _outStoreName = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string outCashierName
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }
        private string _out_goods_name = "";
        /// <summary>
        /// 商品名称
        /// </summary>
        public string outGoodsName
        {
            get { return _out_goods_name; }
            set { _out_goods_name = value; }
        }
        private string _outOrderNo = "";
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string outOrderNo
        {
            get { return _outOrderNo; }
            set { _outOrderNo = value; }
        }
        private string _out_sub_appid = "";
        /// <summary>
        /// 商户公众号ID
        /// </summary>
        public string outSubAppId
        {
            get { return _out_sub_appid; }
            set { _out_sub_appid = value; }
        }
        private string _outSubOpenId = "";
        /// <summary>
        /// 公众号openId
        /// </summary>
        public string outSubOpenId
        {
            get { return _outSubOpenId; }
            set { _outSubOpenId = value; }
        }
        private string _orderNo = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string orderNo
        {
            get { return _orderNo; }
            set { _orderNo = value; }
        }

        private string _orderStatus = "";
        /// <summary>
        /// 订单状态
        /// </summary>
        public string orderStatus
        {
            get { return _orderStatus; }
            set { _orderStatus = value; }
        }
        private string _orderTime = "";
        /// <summary>
        /// 订单时间
        /// </summary>
        public string orderTime
        {
            get { return _orderTime; }
            set { _orderTime = value; }
        }
        private string _amount = "";
        /// <summary>
        /// 支付金额
        /// </summary>
        public string amount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string payType
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }
        private string _orderStatusMsg = "";
        /// <summary>
        /// 订单状态描述
        /// </summary>
        public string orderStatusMsg
        {
            get { return _orderStatusMsg; }
            set { _orderStatusMsg = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
        #region H5调起微信支付参数
        private string _jsAppId = "";
        /// <summary>
        /// jsAppId
        /// </summary>
        public string jsAppId
        {
            get { return _jsAppId; }
            set { _jsAppId = value; }
        }
        private string _jsTimeStamp = "";
        /// <summary>
        /// jsTimeStamp
        /// </summary>
        public string jsTimeStamp
        {
            get { return _jsTimeStamp; }
            set { _jsTimeStamp = value; }
        }
        private string _jsSignType = "";
        /// <summary>
        /// jsSignType
        /// </summary>
        public string jsSignType
        {
            get { return _jsSignType; }
            set { _jsSignType = value; }
        }
        private string _jsPackages = "";
        /// <summary>
        /// jsPackages
        /// </summary>
        public string jsPackages
        {
            get { return _jsPackages; }
            set { _jsPackages = value; }
        }
        private string _jsNonceStr = "";
        /// <summary>
        /// jsNonceStr
        /// </summary>
        public string jsNonceStr
        {
            get { return _jsNonceStr; }
            set { _jsNonceStr = value; }
        }
        private string _jsPaySign = "";
        /// <summary>
        /// jsPaySign
        /// </summary>
        public string jsPaySign
        {
            get { return _jsPaySign; }
            set { _jsPaySign = value; }
        }
        #endregion H5调起微信支付参数
    }

    public class Scan_payReturnModel
    {
        private string _merchantAccount = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchantAccount
        {
            get { return _merchantAccount; }
            set { _merchantAccount = value; }
        }
        private string _outStoreName = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string outStoreName
        {
            get { return _outStoreName; }
            set { _outStoreName = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string outCashierName
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }
        private string _out_goods_name = "";
        /// <summary>
        /// 商品名称
        /// </summary>
        public string outGoodsName
        {
            get { return _out_goods_name; }
            set { _out_goods_name = value; }
        }
        private string _outOrderNo = "";
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string outOrderNo
        {
            get { return _outOrderNo; }
            set { _outOrderNo = value; }
        }
        private string _localTime = "";
        /// <summary>
        /// 当地时间
        /// </summary>
        public string localTime
        {
            get { return _localTime; }
            set { _localTime = value; }
        }
        private string _orderNo = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string orderNo
        {
            get { return _orderNo; }
            set { _orderNo = value; }
        }

        private string _orderStatus = "";
        /// <summary>
        /// 订单状态
        /// </summary>
        public string orderStatus
        {
            get { return _orderStatus; }
            set { _orderStatus = value; }
        }
        private string _orderTime = "";
        /// <summary>
        /// 订单时间
        /// </summary>
        public string orderTime
        {
            get { return _orderTime; }
            set { _orderTime = value; }
        }
        private string _fee_type = "";
        /// <summary>
        /// 币种
        /// </summary>
        public string feeType
        {
            get { return _fee_type; }
            set { _fee_type = value; }
        }
        private string _terminal_type = "";
        /// <summary>
        /// 终端类型
        /// </summary>
        public string terminalType
        {
            get { return _terminal_type; }
            set { _terminal_type = value; }
        }
        private string _amount = "";
        /// <summary>
        /// 支付金额
        /// </summary>
        public string amount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        private string _rateAfterAmount = "";
        /// <summary>
        /// rateAfterAmount
        /// </summary>
        public string rateAfterAmount
        {
            get { return _rateAfterAmount; }
            set { _rateAfterAmount = value; }
        }
        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string payType
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }
        private string _orderStatusMsg = "";
        /// <summary>
        /// 订单状态描述
        /// </summary>
        public string orderStatusMsg
        {
            get { return _orderStatusMsg; }
            set { _orderStatusMsg = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }

    public class Qrcode_payReturnModel
    {
        private string _merchantAccount = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchantAccount
        {
            get { return _merchantAccount; }
            set { _merchantAccount = value; }
        }
        private string _outStoreName = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string outStoreName
        {
            get { return _outStoreName; }
            set { _outStoreName = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string outCashierName
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }
        private string _out_goods_name = "";
        /// <summary>
        /// 商品名称
        /// </summary>
        public string outGoodsName
        {
            get { return _out_goods_name; }
            set { _out_goods_name = value; }
        }
        private string _outOrderNo = "";
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string outOrderNo
        {
            get { return _outOrderNo; }
            set { _outOrderNo = value; }
        }
        private string _codeUrl = "";
        /// <summary>
        /// 原支付二维码url：二维码图片中的实际内容
        /// </summary>
        public string codeUrl
        {
            get { return _codeUrl; }
            set { _codeUrl = value; }
        }
        private string _qrCodeUrl = "";
        /// <summary>
        /// 二维码图片链接：返回一张二维码图片
        /// </summary>
        public string qrCodeUrl
        {
            get { return _qrCodeUrl; }
            set { _qrCodeUrl = value; }
        }
        private string _qrCodeName = "";
        /// <summary>
        /// 二维码图片名称
        /// </summary>
        public string qrCodeName
        {
            get { return _qrCodeName; }
            set { _qrCodeName = value; }
        }
        private string _orderNo = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string orderNo
        {
            get { return _orderNo; }
            set { _orderNo = value; }
        }

        private string _orderStatus = "";
        /// <summary>
        /// 订单状态
        /// </summary>
        public string orderStatus
        {
            get { return _orderStatus; }
            set { _orderStatus = value; }
        }
        private string _orderTime = "";
        /// <summary>
        /// 订单时间
        /// </summary>
        public string orderTime
        {
            get { return _orderTime; }
            set { _orderTime = value; }
        }
        private string _amount = "";
        /// <summary>
        /// 支付金额
        /// </summary>
        public string amount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string payType
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }
        private string _orderStatusMsg = "";
        /// <summary>
        /// 订单状态描述
        /// </summary>
        public string orderStatusMsg
        {
            get { return _orderStatusMsg; }
            set { _orderStatusMsg = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }
}
