﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Payment.Model
{
    public class Store_singleSendModel
    {

        private string _merchant_account = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchant_account
        {
            get { return _merchant_account; }
            set { _merchant_account = value; }
        }
        private string _out_store_name = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string out_store_name
        {
            get { return _out_store_name; }
            set { _out_store_name = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string out_cashier_name
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }

        private string _order_no = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string order_no
        {
            get { return _order_no; }
            set { _order_no = value; }
        }
        private string _partner_code = "";
        /// <summary>
        /// 第三方标识
        /// </summary>
        public string partner_code
        {
            get { return _partner_code; }
            set { _partner_code = value; }
        }
        private string _token = "";
        /// <summary>
        /// Access token
        /// </summary>
        public string token
        {
            get { return _token; }
            set { _token = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }

    public class StoreSendModel
    {

        private string _merchant_account = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchant_account
        {
            get { return _merchant_account; }
            set { _merchant_account = value; }
        }
        private string _out_store_name = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string out_store_name
        {
            get { return _out_store_name; }
            set { _out_store_name = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string out_cashier_name
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }

        private string _order_time_start = "";
        /// <summary>
        /// 订单开始查询日
        /// </summary>
        public string order_time_start
        {
            get { return _order_time_start; }
            set { _order_time_start = value; }
        }

        private string _order_time_end = "";
        /// <summary>
        /// 订单截止查询日
        /// </summary>
        public string order_time_end
        {
            get { return _order_time_end; }
            set { _order_time_end = value; }
        }

        private string _page_size = "";
        /// <summary>
        /// 每页条数
        /// </summary>
        public string page_size
        {
            get { return _page_size; }
            set { _page_size = value; }
        }

        private string _page_no = "";
        /// <summary>
        /// 当前页
        /// </summary>
        public string page_no
        {
            get { return _page_no; }
            set { _page_no = value; }
        }
        private string _partner_code = "";
        /// <summary>
        /// 第三方标识
        /// </summary>
        public string partner_code
        {
            get { return _partner_code; }
            set { _partner_code = value; }
        }
        private string _token = "";
        /// <summary>
        /// Access token
        /// </summary>
        public string token
        {
            get { return _token; }
            set { _token = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }

    public class StoreReturnModel
    {
        private string _outStoreName = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string storeAccount
        {
            get { return _outStoreName; }
            set { _outStoreName = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string cashierAccount
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }
        private string _goodsName = "";
        /// <summary>
        /// 商品名称
        /// </summary>
        public string goodsName
        {
            get { return _goodsName; }
            set { _goodsName = value; }
        }

        private string _outOrderNo = "";
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string outOrderNo
        {
            get { return _outOrderNo; }
            set { _outOrderNo = value; }
        }
        private string _orderNo = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string orderNo
        {
            get { return _orderNo; }
            set { _orderNo = value; }
        }

        private string _orderStatus = "";
        /// <summary>
        /// 订单状态
        /// </summary>
        public string orderStatus
        {
            get { return _orderStatus; }
            set { _orderStatus = value; }
        }
        private string _orderTime = "";
        /// <summary>
        /// 订单时间
        /// </summary>
        public string orderTime
        {
            get { return _orderTime; }
            set { _orderTime = value; }
        }
        private string _amount = "";
        /// <summary>
        /// 支付金额
        /// </summary>
        public string amount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string payType
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }

        private string _rateAfterAmount = "";
        /// <summary>
        /// rateAfterAmount
        /// </summary>
        public string rateAfterAmount
        {
            get { return _rateAfterAmount; }
            set { _rateAfterAmount = value; }
        }

        private string _payTypeName = "";
        /// <summary>
        /// 交易方式名称
        /// </summary>
        public string payTypeName
        {
            get { return _payTypeName; }
            set { _payTypeName = value; }
        }
        private string _orderStatusMsg = "";
        /// <summary>
        /// 订单状态描述
        /// </summary>
        public string orderStatusMsg
        {
            get { return _orderStatusMsg; }
            set { _orderStatusMsg = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }

        private string _subAccountInfo = "";

        public string subAccountInfo
        {
            get { return _subAccountInfo; }
            set { _subAccountInfo = value; }
        }

        //private List<SubAccountInfo> _subAccountInfo = new List<SubAccountInfo>();

        //public List<SubAccountInfo> subAccountInfo
        //{
        //    get { return _subAccountInfo; }
        //    set { _subAccountInfo = value; }
        //}
    }

    
    public class SubAccountInfo{
         private string  _accountState="";

public string accountState
{
  get { return _accountState; }
  set { _accountState = value; }
}
         private string  _amount="";

public string amount
{
  get { return _amount; }
  set { _amount = value; }
}
         private string  _merchant="";

public string merchant
{
  get { return _merchant; }
  set { _merchant = value; }
}
         private string  _merchantReceivers="";

public string merchantReceivers
{
  get { return _merchantReceivers; }
  set { _merchantReceivers = value; }
}
    }
}
