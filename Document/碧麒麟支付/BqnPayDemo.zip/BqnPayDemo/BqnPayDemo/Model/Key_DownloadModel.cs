﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Payment.Model
{
    public class Key_DownloadSendModel
    {
        private string _merchant_account = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchant_account
        {
            get { return _merchant_account; }
            set { _merchant_account = value; }
        }
        private string _merchant_pwd = "";
        /// <summary>
        /// 商户密码
        /// </summary>
        public string merchant_pwd
        {
            get { return _merchant_pwd; }
            set { _merchant_pwd = value; }
        }
        private string _partner_code = "";
        /// <summary>
        /// 第三方标识
        /// </summary>
        public string partner_code
        {
            get { return _partner_code; }
            set { _partner_code = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }

    public class Key_DownloadReturnModel
    {
        private string _merchantAccount = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchantAccount
        {
            get { return _merchantAccount; }
            set { _merchantAccount = value; }
        }
        private string _merchantName = "";
        /// <summary>
        /// 商户名称
        /// </summary>
        public string merchantName
        {
            get { return _merchantName; }
            set { _merchantName = value; }
        }
        private string _serviceMerchantAccount = "";
        /// <summary>
        /// 服务商账号
        /// </summary>
        public string serviceMerchantAccount
        {
            get { return _serviceMerchantAccount; }
            set { _serviceMerchantAccount = value; }
        }
        private string _serviceMerchantName = "";
        /// <summary>
        /// 服务商名称
        /// </summary>
        public string serviceMerchantName
        {
            get { return _serviceMerchantName; }
            set { _serviceMerchantName = value; }
        }
        private string _serviceMerchantPhone = "";
        /// <summary>
        /// 服务商联系电话
        /// </summary>
        public string serviceMerchantPhone
        {
            get { return _serviceMerchantPhone; }
            set { _serviceMerchantPhone = value; }
        }
        private string _token = "";
        /// <summary>
        /// Access token
        /// </summary>
        public string token
        {
            get { return _token; }
            set { _token = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }
}
