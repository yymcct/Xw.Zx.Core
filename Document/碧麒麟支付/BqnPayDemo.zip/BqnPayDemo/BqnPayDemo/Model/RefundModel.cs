﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Payment.Model
{
    public class RefundSendModel
    {
        private string _merchant_account = "";
        /// <summary>
        /// 商户账号
        /// </summary>
        public string merchant_account
        {
            get { return _merchant_account; }
            set { _merchant_account = value; }
        }
        private string _out_store_name = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string out_store_name
        {
            get { return _out_store_name; }
            set { _out_store_name = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string out_cashier_name
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }

        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string pay_type
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }
        private string _order_no = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string order_no
        {
            get { return _order_no; }
            set { _order_no = value; }
        }
        private string _partner_code = "";
        /// <summary>
        /// 第三方标识
        /// </summary>
        public string partner_code
        {
            get { return _partner_code; }
            set { _partner_code = value; }
        }
        private string _token = "";
        /// <summary>
        /// Access token
        /// </summary>
        public string token
        {
            get { return _token; }
            set { _token = value; }
        }
        private string _money = "";
        /// <summary>
        /// money
        /// </summary>
        public string money
        {
            get { return _money; }
            set { _money = value; }
        }
        private string _sign = "";
        /// <summary>
        /// 接口签名
        /// </summary>
        public string sign
        {
            get { return _sign; }
            set { _sign = value; }
        }
    }

    public class RefundReturnModel
    {
        private string _outStoreName = "";
        /// <summary>
        /// 门店名称
        /// </summary>
        public string outStoreName
        {
            get { return _outStoreName; }
            set { _outStoreName = value; }
        }
        private string _out_cashier_name = "";
        /// <summary>
        /// 收银员姓名
        /// </summary>
        public string outCashierName
        {
            get { return _out_cashier_name; }
            set { _out_cashier_name = value; }
        }
        private string _goodsname = "";
        /// <summary>
        /// 商品名称
        /// </summary>
        public string goodsname
        {
            get { return _goodsname; }
            set { _goodsname = value; }
        }
        private string _outOrderNo = "";
        /// <summary>
        /// 商户订单号
        /// </summary>
        public string outOrderNo
        {
            get { return _outOrderNo; }
            set { _outOrderNo = value; }
        }
        private string _orderNo = "";
        /// <summary>
        /// 碧麒麟订单号
        /// </summary>
        public string orderNo
        {
            get { return _orderNo; }
            set { _orderNo = value; }
        }

        private string _orderStatus = "";
        /// <summary>
        /// 订单状态
        /// </summary>
        public string orderStatus
        {
            get { return _orderStatus; }
            set { _orderStatus = value; }
        }
        private string _orderTime = "";
        /// <summary>
        /// 订单时间
        /// </summary>
        public string orderTime
        {
            get { return _orderTime; }
            set { _orderTime = value; }
        }
        private string _amount = "";
        /// <summary>
        /// 退款金额
        /// </summary>
        public string refundAmount
        {
            get { return _amount; }
            set { _amount = value; }
        }
        private string _pay_type = "";
        /// <summary>
        /// 交易方式
        /// </summary>
        public string payType
        {
            get { return _pay_type; }
            set { _pay_type = value; }
        }
    }
}
