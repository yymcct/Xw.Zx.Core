﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Common.Payment.Model
{
    public class MerchantInfoModel
    {

        private string _merchantaccount = "";
        /// <summary>
        /// MerchantAccount
        /// </summary>
        public string MerchantAccount
        {
            get { return _merchantaccount; }
            set { _merchantaccount = value; }
        }
        private string _merchantpwd = "";
        /// <summary>
        /// MerchantPwd
        /// </summary>
        public string MerchantPwd
        {
            get { return _merchantpwd; }
            set { _merchantpwd = value; }
        }
        private string _partnercode = "";
        /// <summary>
        /// PartnerCode
        /// </summary>
        public string PartnerCode
        {
            get { return _partnercode; }
            set { _partnercode = value; }
        }
        private string _requestkey = "";
        /// <summary>
        /// RequestKey
        /// </summary>
        public string RequestKey
        {
            get { return _requestkey; }
            set { _requestkey = value; }
        }
        private string _responsekey = "";
        /// <summary>
        /// ResponseKey
        /// </summary>
        public string ResponseKey
        {
            get { return _responsekey; }
            set { _responsekey = value; }
        }
        private string _appID = "";
        public string AppID
        {
            get { return _appID; }
            set { _appID = value; }
        }
        private string _url = "";
        /// <summary>
        /// URL
        /// </summary>
        public string URL
        {
            get { return _url; }
            set { _url = value; }
        }
        private int _payplatform = 0;
        /// <summary>
        /// PayPlatform
        /// </summary>
        public int PayPlatform
        {
            get { return _payplatform; }
            set { _payplatform = value; }
        }
        private string _StationNo = "";
        /// <summary>
        /// StationNo
        /// </summary>
        public string StationNo
        {
            get { return _StationNo; }
            set { _StationNo = value; }
        }
        private string _StationName = "";
        /// <summary>
        ///StationName
        /// </summary>
        public string StationName
        {
            get { return _StationName; }
            set { _StationName = value; }
        }

        private string _AccessToken = "";
        /// <summary>
        ///Token
        /// </summary>
        public string AccessToken
        {
            get { return _AccessToken; }
            set { _AccessToken = value; }
        }

        private List<MobilePayInterfaceURLModel> _MobilePayInterfaceURLList = new List<MobilePayInterfaceURLModel>();
        /// <summary>
        /// 支付接口地址列表
        /// </summary>
        public List<MobilePayInterfaceURLModel> MobilePayInterfaceURLList
        {
            get { return _MobilePayInterfaceURLList; }
            set { _MobilePayInterfaceURLList = value; }
        }

    }

    public class MobilePayInterfaceURLModel
    {

        private string _interfacename = "";
        /// <summary>
        /// InterfaceName
        /// </summary>
        public string InterfaceName
        {
            get { return _interfacename; }
            set { _interfacename = value; }
        }
        private string _interfaceurl = "";
        /// <summary>
        /// InterfaceURL
        /// </summary>
        public string InterfaceURL
        {
            get { return _interfaceurl; }
            set { _interfaceurl = value; }
        }
        private int _payplatform = 0;
        /// <summary>
        /// PayPlatform
        /// </summary>
        public int PayPlatform
        {
            get { return _payplatform; }
            set { _payplatform = value; }
        }

    }
}
