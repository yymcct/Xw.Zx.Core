﻿<%@ WebHandler Language="C#" CodeBehind="PayHandler.ashx.cs" Class="BqnPayDemo.PayHandler" %>
