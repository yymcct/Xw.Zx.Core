﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Common.Payment;
using Common.Payment.Model;

namespace BqnPayDemo
{
    /// <summary>
    /// Summary description for PayHandler
    /// </summary>
    public class PayHandler : IHttpHandler
    {

        private string _AppID = "wx51585f14e703e071";
        private string _PartnerCode = "yunfeiyang";
        private string _MerchantAccount = "1100000236";
        private string _Token = "224ee8be59ea93d57d6eef36c9751a7d502c462109e245e8985789578a8ad57a"; //功能商户号和密钥通过获取商户访问token接口获取，同一商户唯一不变

        //测试公众号支付，需将公众号appid以及支付域名（支付页面所在的域名）提前给碧麒麟报备，之后才能测试

        public void ProcessRequest(HttpContext context)
        {
            int l_Result = 0;
            string l_ErrStr = "";
            string l_RequestStr = "";
            string l_ReturnJsonStr = "";
            Dictionary<String, Object> l_SendDataDic = new Dictionary<String, Object>();
            PaymentInterface l_PaymentInterface = new PaymentInterface();
            try
            {
                l_RequestStr = CommonFunction.GetJsonStr(context);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, "RunTime.txt", "l_RequestStr:", l_RequestStr, "");

                l_Result = Common.Functions.TJSONFunctions.JsonToDictionary(l_RequestStr, ref l_SendDataDic);

                if (l_Result == 0)
                {
                    PaySendModel l_PaySendModel = new PaySendModel();
                    l_PaySendModel.amount = l_SendDataDic["Amount"].ToString();
                    l_PaySendModel.fee_type = "CNY";
                    DateTime l_OldTime = new DateTime(1970, 1, 1);
                    TimeSpan l_Span = DateTime.Now.Subtract(l_OldTime);
                    l_PaySendModel.local_time = l_Span.TotalMilliseconds.ToString("F0");
                    l_PaySendModel.merchant_account = _MerchantAccount;
                    l_PaySendModel.out_cashier_name = "00";
                    l_PaySendModel.out_goods_name = "测试商品";
                    l_PaySendModel.out_store_name = "测试站点";
                    l_PaySendModel.out_trade_no = System.Guid.NewGuid().ToString().Replace("-", "");
                    l_PaySendModel.partner_code = _PartnerCode;
                    l_PaySendModel.pay_type = "WEIXIN_PAY";
                    l_PaySendModel.terminal_type = "3";
                    l_PaySendModel.token = _Token;

                    l_PaySendModel.out_sub_appid = _AppID;
                    l_PaySendModel.out_sub_openid = l_SendDataDic["OpenId"].ToString();
                    l_PaySendModel.notify_url = "http://www.baidu.com";
                    Common.Payment.Model.Jsapi_payReturnModel l_Jsapi_payReturnModel = new Jsapi_payReturnModel();
                    l_Result = l_PaymentInterface.Jsapi_pay(l_PaySendModel, ref l_Jsapi_payReturnModel, ref l_ErrStr);
                    Common.Functions.TJSONFunctions.ModelToJson(l_Jsapi_payReturnModel, ref l_ReturnJsonStr);
                }
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, "RunTime.txt", "Exception", "catch error:" + Ex.Message, "");
            }

            context.Response.ContentType = "text/plain";
            context.Response.Write(l_ReturnJsonStr);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}