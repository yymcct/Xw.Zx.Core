﻿var appId = "";
var timeStamp = ""
var nonceStr = ""
var packages = ""
var paySign = "";
var paySignType = "";

function pay() {
   openLoading();
    $.ajax({
        async: true,
        type: 'post',
        url: './PayHandler.ashx',
        data: "{ \"Amount\":\"0.01\", \"OpenId\": \"o0bHTwAY0gPSTWEbHQGSkUGGC_Ok\" }",
        success: function (data, textStatus) {
            var datajson = jQuery.parseJSON(data);

            appId = datajson.jsAppId;
            timeStamp = datajson.jsTimeStamp;
            nonceStr = datajson.jsNonceStr;
            packages = datajson.jsPackages;
            paySign = datajson.jsPaySign;
            paySignType = datajson.jsSignType;
            doPay();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            onFailMsg();
        }
    });
}
//调起微信支付
function doPay() {

    if (typeof WeixinJSBridge == "undefined") {
        if (document.addEventListener) {
            document.addEventListener('WeixinJSBridgeReady', onBridgeReady, false);
        } else if (document.attachEvent) {
            document.attachEvent('WeixinJSBridgeReady', onBridgeReady);
            document.attachEvent('onWeixinJSBridgeReady', onBridgeReady);
        }
    } else {
        onBridgeReady();
    }
}
function onBridgeReady() {
    WeixinJSBridge.invoke(
			'getBrandWCPayRequest', {
			    "appId": appId,     //公众号名称，由商户传入     
			    "timeStamp": timeStamp,         //时间戳，自1970年以来的秒数     
			    "nonceStr": nonceStr, //随机串     
			    "package": packages,
			    "signType": paySignType,         //微信签名方式：     
			    "paySign": paySign //微信签名 
			}, function (res) {
			    closeLoading();
			    //使用以下方式判断前端返回,微信团队郑重提示：res.err_msg将在用户支付成功后返回    ok，但并不保证它绝对可靠。 
			    if (res.err_msg == "get_brand_wcpay_request:ok") {
			        //支付成功
			        onSuccessMsg();
			    } else {
			        //弹出之后，苹果手机会卡死
			        //alert(res.err_desc);
			    }
			}
	);
}
//loading 
function openLoading() {
    layer.open({
        type: 2,
        shadeClose: false
    });
}
function closeLoading() {
    layer.closeAll();
}
//支付成功
function onSuccessMsg() {
    layer.open({
        content: '支付成功！',
        btn: ['确认'],
        shadeClose: false,
        yes: function () {
            WeixinJSBridge.call('closeWindow');
        }
    });
}
//支付失败
function onFailMsg() {
    closeLoading();
    layer.open({
        content: '支付失败！',
        btn: ['确认'],
        shadeClose: false
    });
}