﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Common.Payment.Model;
using System.Security.Cryptography;
using System.Windows.Forms;
using System.IO;

namespace Common.Payment
{
    public class PaymentInterface
    {
        private bool _IsLog = true;
        string _LogFileName = "RunTime.txt";

        string _LocalToken = "3D201DC766186AAE0D92B45504C6F5FB";
        /// <summary>
        /// 请求密钥
        /// </summary>
        string _RequestKey = "OT83bBmTInLY9mrP";
        /// <summary>
        /// 响应密钥
        /// </summary>
        string _ResponseKey = "8EDTzniPlQORVi69IVX1n5vbKXh2ECch";

        //public string _URL = "https://unionpos.biqilin.com";
        public string _URL = "https://pay.biqilin.com";

        //public string _URL = "http://x1940k9291.iask.in";

        /// <summary>
        /// 获取商户访问token
        /// </summary>
        private string _Key_downloadURL = "/api/user/partner/key_download.do";
        /// <summary>
        /// 订单退款接口
        /// </summary>
        private string _RefundURL = "/api/pay/partner/refund.do";
        /// <summary>
        /// 订单查询接口
        /// </summary>
        private string _Store_singleURL = "/api/pay/query/partner/store_single2.do";
        /// <summary>
        /// 订单查询接口
        /// </summary>
        private string _StorePageURL = "/api/pay/query/partner/store_page2.do";
        /// <summary>
        /// 公众号支付预下单接口
        /// </summary>
        private string _Jsapi_payURL = "/api/pay/partner/jsapi_pay2.do";
        /// <summary>
        /// 扫码支付接口
        /// </summary>
        private string _Scan_payURL = "/api/pay/partner/scan_pay2.do";
        /// <summary>
        /// 二维码支付接口
        /// qrcode_pay2.do和qrcode_pay.do的区别，qrcode_pay.do这个是聚合二维码
        /// 测试云闪付的时候发现和微信/支付宝扫二维码不一样  没有整合进去。云闪付app对于其他二维码会跳转到浏览器。
        /// qrcode_pay.do 不需要pay_type参数
        /// </summary>
        private string _Qrcode_payURL2 = "/api/pay/partner/qrcode_pay2.do";
        private string _Qrcode_payURL = "/api/pay/partner/qrcode_pay.do";

        #region 调用bqn

        /// <summary>
        /// 获取商户访问token
        /// </summary>
        /// <param name="v_Key_DownloadSendModel"></param>
        /// <param name="v_Key_DownloadReturnModel"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int KeyDownload(ref Model.Key_DownloadSendModel v_Key_DownloadSendModel, ref Model.Key_DownloadReturnModel v_Key_DownloadReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                //byte[] l_Vector = { 0x12, 0x34, 0x56, 0x78, 0x87, 0x65, 0x43, 0x21 };
                //string l_EncryptStr = "";
                //string l_DecryptStr = "";
                //v_Key_DownloadSendModel.merchant_account = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "System", "MerchantAccount", "");
                //l_EncryptStr = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "System", "MerchantPwd", "");
                //Common.Functions.TFunctions.Decrypt(1, l_Vector, l_EncryptStr, ref l_DecryptStr);
                //v_Key_DownloadSendModel.merchant_pwd = l_DecryptStr;
                //v_Key_DownloadSendModel.partner_code = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "System", "PartnerCode", "");
                //l_EncryptStr = "";
                //l_DecryptStr = "";
                //l_EncryptStr = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "System", "RequestKey", "");
                //Common.Functions.TFunctions.Decrypt(1, l_Vector, l_EncryptStr, ref l_DecryptStr);
                //_RequestKey = l_DecryptStr;
                //l_EncryptStr = "";
                //l_DecryptStr = "";
                //l_EncryptStr = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "System", "ResponseKey", "");
                //Common.Functions.TFunctions.Decrypt(1, l_Vector, l_EncryptStr, ref l_DecryptStr);
                //_ResponseKey = l_DecryptStr;
                //_URL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "System", "URL", "");

                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "merchant_account=" + v_Key_DownloadSendModel.merchant_account
                    + "&merchant_pwd=" + v_Key_DownloadSendModel.merchant_pwd
                    + "&partner_code=" + v_Key_DownloadSendModel.partner_code;
                v_Key_DownloadSendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_Key_DownloadSendModel.sign;
                string l_SendJsonStrLog = "merchant_account=" + v_Key_DownloadSendModel.merchant_account
                     + "&partner_code=" + v_Key_DownloadSendModel.partner_code + "&sign=" + v_Key_DownloadSendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "KeyDownload", "Send：" + l_SendJsonStrLog, "");
                //_Key_downloadURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "KeyDownloadURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _Key_downloadURL, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "KeyDownload", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_Key_DownloadReturnModel);
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "KeyDownload()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;

        }

        public int KeyDownload(string v_Mid, string v_Pwd, ref Model.Key_DownloadReturnModel v_Key_DownloadReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "merchant_account=" + v_Mid
                    + "&merchant_pwd=" + v_Pwd
                    + "&partner_code=yunfeiyang";
                l_SendJsonStr = l_TempStr + "&sign=" + CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                 Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "KeyDownload", "Send：" + l_SendJsonStr, "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _Key_downloadURL, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "KeyDownload", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_Key_DownloadReturnModel);
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "KeyDownload()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;

        }

        /// <summary>
        /// 订单退款接口
        /// </summary>
        /// <param name="v_RefundSendModel"></param>
        /// <param name="v_RefundReturnModel"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int Refund(Model.RefundSendModel v_RefundSendModel, ref Model.RefundReturnModel v_RefundReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                //1000003876423917292270021
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "memo1=" + v_RefundSendModel.money
                    + "&merchant_account=" + v_RefundSendModel.merchant_account
                    + "&order_no=" + v_RefundSendModel.order_no
                    + "&out_cashier_name=" + v_RefundSendModel.out_cashier_name
                    + "&out_store_name=" + v_RefundSendModel.out_store_name
                    + "&partner_code=" + v_RefundSendModel.partner_code
                    + "&pay_type=" + v_RefundSendModel.pay_type
                    + "&token=" + v_RefundSendModel.token;
                v_RefundSendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_RefundSendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Refund:HttpPost", "RequestURL：" + _URL + _RefundURL + "，l_SendJsonStr：" + l_SendJsonStr, "");
                //_RefundURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "RefundURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _RefundURL, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Refund:HttpPost", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_RefundReturnModel);
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "Refund()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;
        }

        /// <summary>
        /// 订单查询接口
        /// </summary>
        /// <param name="v_Store_singleSendModel"></param>
        /// <param name="v_StoreReturnModel"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int Store_single(Model.Store_singleSendModel v_Store_singleSendModel, ref Model.StoreReturnModel v_StoreReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "merchant_account=" + v_Store_singleSendModel.merchant_account
                    + "&order_no=" + v_Store_singleSendModel.order_no
                    + "&out_cashier_name=" + v_Store_singleSendModel.out_cashier_name
                    + "&out_store_name=" + v_Store_singleSendModel.out_store_name
                    + "&partner_code=" + v_Store_singleSendModel.partner_code
                    + "&token=" + v_Store_singleSendModel.token;
                v_Store_singleSendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_Store_singleSendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Store_single:HttpPost", "RequestURL：" + _URL + _Store_singleURL + "，l_SendJsonStr：" + l_SendJsonStr, "");
                //_Store_singleURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "StoreSingleURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _Store_singleURL, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Store_single:HttpPost", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_StoreReturnModel);
                    if (v_StoreReturnModel.payType == "WEIXIN_PAY")
                        v_StoreReturnModel.payTypeName = Resources.StrWEIXINPAY;
                    else if (v_StoreReturnModel.payType == "ALI_PAY")
                        v_StoreReturnModel.payTypeName = Resources.StrALIPAY;
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "Store_single()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;
        }

        /// <summary>
        /// 订单查询接口
        /// </summary>
        /// <param name="v_StoreSendModel"></param>
        /// <param name="v_StoreReturnList"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int QueryStore(Model.StoreSendModel v_StoreSendModel, ref List<Model.StoreReturnModel> v_StoreReturnList, ref int v_Count, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "merchant_account=" + v_StoreSendModel.merchant_account
                    + "&order_time_end=" + v_StoreSendModel.order_time_end
                    + "&order_time_start=" + v_StoreSendModel.order_time_start
                   + "&out_cashier_name=" + v_StoreSendModel.out_cashier_name
                   + "&out_store_name=" + v_StoreSendModel.out_store_name
               + "&page_no=" + v_StoreSendModel.page_no
               + "&page_size=" + v_StoreSendModel.page_size
               + "&partner_code=" + v_StoreSendModel.partner_code
               + "&token=" + v_StoreSendModel.token;
                v_StoreSendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_StoreSendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "QueryStore:HttpPost", "RequestURL：" + _URL + _StorePageURL + "，l_SendJsonStr：" + l_SendJsonStr, "");
                //_StorePageURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "StorePageURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _StorePageURL, l_SendJsonStr);
                //Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "QueryStore:HttpPost", "Receive：" + l_ReceiveStr, "");
                if (l_ReceiveStr != null)
                {
                    Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                    Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                    v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                    if (l_ReceiveDataDic["errorCode"].ToString() == "")
                    {
                        v_Count = int.Parse(l_ReceiveDataDic["total"].ToString());
                        if (v_Count > 0)
                        {
                            System.Collections.ArrayList l_TempList = new System.Collections.ArrayList();
                            l_TempList = (System.Collections.ArrayList)l_ReceiveDataDic["list"];
                            Model.StoreReturnModel l_StoreReturnModel = null;
                            string l_ReturnModelStr = "";
                            for (int i = 0; i < l_TempList.Count; i++)
                            {
                                l_StoreReturnModel = new StoreReturnModel();
                                l_ReturnModelStr = "";
                                Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_TempList[i], ref l_ReturnModelStr);
                                Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref l_StoreReturnModel);
                                if (l_StoreReturnModel.payType == "WEIXIN_PAY")
                                    l_StoreReturnModel.payTypeName = Resources.StrWEIXINPAY;
                                else if (l_StoreReturnModel.payType == "ALI_PAY")
                                    l_StoreReturnModel.payTypeName = Resources.StrALIPAY;
                                v_StoreReturnList.Add(l_StoreReturnModel);

                            }
                        }
                    }
                    else
                        l_Result = -1;
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "Store_single()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "QueryStore:End", "Result：" + l_Result.ToString() + "ErrorStr：" + v_ErrorStr, "");
            return l_Result;
        }


        /// <summary>
        /// 公众号支付预下单接口
        /// </summary>
        /// <param name="v_PaySendModel"></param>
        /// <param name="v_Jsapi_payReturnModel"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int Jsapi_pay(Model.PaySendModel v_PaySendModel, ref Model.Jsapi_payReturnModel v_Jsapi_payReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "amount=" + v_PaySendModel.amount
                    + "&fee_type=" + v_PaySendModel.fee_type
                    + "&local_time=" + v_PaySendModel.local_time
                    + "&merchant_account=" + v_PaySendModel.merchant_account
                    + "&notify_url=" + v_PaySendModel.notify_url
                    + "&out_cashier_name=" + v_PaySendModel.out_cashier_name
                    + "&out_goods_name=" + v_PaySendModel.out_goods_name
                    + "&out_store_name=" + v_PaySendModel.out_store_name
                
                   +"&out_sub_appid=" + v_PaySendModel.out_sub_appid
               +"&out_sub_openid=" + v_PaySendModel.out_sub_openid
                           + "&out_trade_no=" + v_PaySendModel.out_trade_no
                           + "&partner_code=" + v_PaySendModel.partner_code
                           + "&pay_type=" + v_PaySendModel.pay_type
                           + "&terminal_type=" + v_PaySendModel.terminal_type
                           + "&token=" + v_PaySendModel.token;
                //Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, false, _LogFileName, "Jsapi_pay", "Sign：" + l_TempStr + "&key=" + _RequestKey, "");
                v_PaySendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_PaySendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Jsapi_pay", "RequestURL：" + _URL + _Jsapi_payURL + "，l_SendJsonStr：" + l_SendJsonStr, "");
                //_Jsapi_payURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "JsapiPayURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _Jsapi_payURL, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Jsapi_pay", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_Jsapi_payReturnModel);
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "Jsapi_pay()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;
        }

        /// <summary>
        /// 扫码支付接口
        /// </summary>
        /// <param name="v_PaySendModel"></param>
        /// <param name="v_Scan_payReturnModel"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int Scan_pay(Model.PaySendModel v_PaySendModel, ref Model.Scan_payReturnModel v_Scan_payReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "amount=" + v_PaySendModel.amount
                    + "&code=" + v_PaySendModel.code
                    + "&fee_type=" + v_PaySendModel.fee_type
                    + "&local_time=" + v_PaySendModel.local_time
                    + "&merchant_account=" + v_PaySendModel.merchant_account
                    + "&out_cashier_name=" + v_PaySendModel.out_cashier_name
                    + "&out_goods_name=" + v_PaySendModel.out_goods_name
                    + "&out_store_name=" + v_PaySendModel.out_store_name
                           + "&out_trade_no=" + v_PaySendModel.out_trade_no
                           + "&partner_code=" + v_PaySendModel.partner_code
                           + "&pay_type=" + v_PaySendModel.pay_type
                           + "&terminal_type=" + v_PaySendModel.terminal_type
                           + "&token=" + v_PaySendModel.token;
                //Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, false, _LogFileName, "Scan_pay", "Sign：" + l_TempStr + "&key=" + _RequestKey, "");
                v_PaySendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_PaySendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Scan_pay", "RequestURL：" + _URL + _Scan_payURL + "，l_SendJsonStr：" + l_SendJsonStr, "");
                //_Scan_payURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "ScanPayURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _Scan_payURL, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Scan_pay", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "" || v_ErrorStr == "支付中")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_Scan_payReturnModel);
                    if (l_ReceiveDataDic["errorCode"].ToString() != "")
                        l_Result = -1;
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "Scan_pay()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;
        }

        /// <summary>
        /// 二维码支付接口
        /// </summary>
        /// <param name="v_PaySendModel"></param>
        /// <param name="v_Qrcode_payReturnModel"></param>
        /// <param name="v_ErrorStr"></param>
        /// <returns></returns>
        public int Qrcode_pay(Model.PaySendModel v_PaySendModel, ref Model.Qrcode_payReturnModel v_Qrcode_payReturnModel, ref string v_ErrorStr)
        {
            int l_Result = 0;
            try
            {
                string l_SendJsonStr = "", l_ReceiveStr = "";
                string l_TempStr = "amount=" + v_PaySendModel.amount
                    + "&fee_type=" + v_PaySendModel.fee_type
                    + "&local_time=" + v_PaySendModel.local_time
                    + "&merchant_account=" + v_PaySendModel.merchant_account
                    + "&notify_url=" + v_PaySendModel.notify_url
                    + "&out_cashier_name=" + v_PaySendModel.out_cashier_name
                    + "&out_goods_name=" + v_PaySendModel.out_goods_name
                    + "&out_store_name=" + v_PaySendModel.out_store_name
                           + "&out_trade_no=" + v_PaySendModel.out_trade_no
                           + "&partner_code=" + v_PaySendModel.partner_code
                           + "&pay_type=" + v_PaySendModel.pay_type
                           + "&terminal_type=" + v_PaySendModel.terminal_type
                           + "&token=" + v_PaySendModel.token;
                // Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, false, _LogFileName, "Qrcode_pay", "Sign：" + l_TempStr + "&key=" + _RequestKey, "");
                v_PaySendModel.sign = CommonFunction.GetMD5(l_TempStr + "&key=" + _RequestKey);
                l_SendJsonStr = l_TempStr + "&sign=" + v_PaySendModel.sign;
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Qrcode_pay", "RequestURL：" + _URL + _Qrcode_payURL2 + "，l_SendJsonStr：" + l_SendJsonStr, "");
                //_Qrcode_payURL = Common.Functions.TXMLIni.TReadNodeString(_ConfigFilePath, "InterfaceURL", "QrcodePayURL", "");
                l_ReceiveStr = CommonFunction.HttpPost(_URL + _Qrcode_payURL2, l_SendJsonStr);
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, _IsLog, _LogFileName, "Qrcode_pay", "Receive：" + l_ReceiveStr, "");
                Dictionary<String, Object> l_ReceiveDataDic = new Dictionary<String, Object>();
                Common.Functions.TJSONFunctions.JsonToDictionary(l_ReceiveStr, ref l_ReceiveDataDic);
                v_ErrorStr = l_ReceiveDataDic["errorMsg"].ToString();
                if (l_ReceiveDataDic["errorCode"].ToString() == "")
                {
                    string l_ReturnModelStr = "";
                    Common.Functions.TJSONFunctions.DictionaryToJson((Dictionary<String, Object>)l_ReceiveDataDic["detail"], ref l_ReturnModelStr);
                    Common.Functions.TJSONFunctions.JsonToModel(l_ReturnModelStr, ref v_Qrcode_payReturnModel);
                }
                else
                    l_Result = -1;
            }
            catch (Exception Ex)
            {
                Common.Functions.TFunctions.WriteLog((int)Common.Functions.TFunctions.ELogTimeUnit.Day, true, _LogFileName, "Qrcode_pay()", "catch error:" + Ex.Message, "");
                l_Result = -1;
                v_ErrorStr = Ex.Message;
            }
            return l_Result;
        }

        #endregion 调用bqn
    }
}
