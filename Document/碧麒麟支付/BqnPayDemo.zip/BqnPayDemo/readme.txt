﻿测试公众号支付，需将公众号appid以及支付域名（支付页面所在的域名）提前给碧麒麟报备，之后才能测试,测试时修改AppID配置及openid的值。
1、private string _AppID = "wx51585f14e703e071";
2、openid在pay.js代码中